@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Qiaoweilai-Bowlong Quant Terminal
echo ============================================================
echo  Qiaoweilai-Bowlong Quant - Web Terminal (Portable Edition)
echo ============================================================
echo.

rem 1) Bundled portable Python (shipped with this installer) - preferred
set "PYEXE=%~dp0runtime\python\python.exe"
if not exist "%PYEXE%" goto :nobundle
goto :checkbundle

:nobundle
rem 2) Fallback: system Python 3.10+ (skip Microsoft Store stub)
set "PYEXE="
for /f "delims=" %%i in ('where python 2^>nul') do (
  echo %%i | find /i "WindowsApps" >nul
  if errorlevel 1 set "PYEXE=%%i"
)
if not defined PYEXE (
  echo [ERROR] No usable Python found. Please reinstall the package.
  pause
  exit /b 1
)
echo Python (system): %PYEXE%
goto :checkport

:checkbundle
echo Python (bundled): %PYEXE%

:checkport
"%PYEXE%" -c "import sys; print(sys.version)"
if errorlevel 1 (
  echo [ERROR] Python found but cannot run. Reinstall the package.
  pause
  exit /b 1
)

netstat -ano | findstr ":8765 " | findstr "LISTENING" >nul
if not errorlevel 1 (
  echo [INFO] Port 8765 is already in use. Checking service health ...
  curl -s --max-time 3 http://127.0.0.1:8765/api/status >nul 2>&1
  if not errorlevel 1 (
    echo [OK] The terminal is already running and healthy.
    echo Opening http://127.0.0.1:8765 in your browser ...
    start "" http://127.0.0.1:8765
  ) else (
    echo [WARN] Port 8765 is occupied by another program, not this service.
    echo Stop that program first, or change the port in web\server.py.
  )
  echo.
  pause
  exit /b 0
)

echo.
echo Starting server ...
echo Open http://127.0.0.1:8765 in your browser
echo Press Ctrl+C in this window to stop the server.
echo.
"%PYEXE%" "%~dp0web\server.py"
set "RC=%ERRORLEVEL%"
echo.
echo Server exited with code %RC%
pause
